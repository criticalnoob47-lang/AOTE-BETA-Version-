
# Automated OpenInsider Evaluator (Scraping + yfinance + Streamlit)

## What it does
- Scrapes insider-trading tables from **OpenInsider** (multi-page).
- Enriches with **market cap** and **current price** via `yfinance`.
- Scores/weights factors (0–1 sliders) and **ranks** stocks.
- Saves/loads **weight presets**.

## Install
```bash
pip install -r requirements.txt
```

## Run
```bash
streamlit run app_streamlit.py
# just put "streamlit run " + draging and droping the file "app_streamlit.py" into the command window
```

## Notes
- The scraper targets OpenInsider tables and attempts to be robust but **HTML can change**; prefer CSV downloads when possible.
- Be polite: throttle requests with the delay setting.
- All factor inputs are **percentile-normalized** before weighting; MarketCap uses **inverse percentile** (smaller = better).
- Title multipliers default: CEO 1.00, CFO 0.95, COO/President 0.90, Director 0.75, 10% Owner 0.60, Other Exec/Officer 0.50, Unknown 0.30.
- Optional **timing bonus** if recent.
